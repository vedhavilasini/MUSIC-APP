import React from 'react'
import NavbarContainer from './Components/NavbarBlock.jsx/NavbarContainer'

const App = () => {
  return (
    <div>
       <NavbarContainer/>
    </div>
  )
}

export default App